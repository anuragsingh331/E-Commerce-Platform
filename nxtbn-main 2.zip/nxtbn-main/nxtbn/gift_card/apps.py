from django.apps import AppConfig


class GiftCardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nxtbn.gift_card'
