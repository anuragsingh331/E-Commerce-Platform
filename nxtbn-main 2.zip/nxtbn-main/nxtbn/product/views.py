from django.shortcuts import render

def product_details(request, slug): # for demonstration purposes
    return 'some-product-details'