from django.dispatch import Signal

order_created = Signal()
customer_logged_in = Signal()
